import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'database_helper.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

// ==========================================
// 1. Models
// ==========================================

// แม่พิมพ์บันทึกไดอารี (SQLite)
class Diary {
  final int? id;
  final String title;
  final String content;
  final String date;
  final String mood;

  Diary({
    this.id,
    required this.title,
    required this.content,
    required this.date,
    required this.mood,
  });

  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      'title': title,
      'content': content,
      'date': date,
      'mood': mood,
    };
    if (id != null) {
      map['id'] = id;
    }
    return map;
  }

  factory Diary.fromMap(Map<String, dynamic> map) {
    return Diary(
      id: map['id'] as int?,
      title: map['title'] as String,
      content: map['content'] as String,
      date: map['date'] as String,
      mood: map['mood'] ?? 'เฉยๆ',
    );
  }
}

// แม่พิมพ์คำคมจาก API (Lab 2)
class Quote {
  final int id;
  final String quote;
  final String author;

  Quote({required this.id, required this.quote, required this.author});

  factory Quote.fromJson(Map<String, dynamic> json) {
    return Quote(
      id: json['id'] as int? ?? 0,
      quote: json['quote'] as String? ?? 'ไม่มีข้อความ',
      author: json['author'] as String? ?? 'ไม่ระบุผู้แต่ง',
    );
  }
}

// ==========================================
// 2. ApiService (Lab 2: timeout + try-catch)
// ==========================================
class ApiService {
  ApiService._();

  // ดึงคำคมแบบสุ่มจาก DummyJSON (มี timeout 10 วินาที และ try-catch กันค้าง)
  static Future<Quote> fetchQuote() async {
    try {
      final url = Uri.parse('https://dummyjson.com/quotes/random');
      final response = await http.get(url).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(utf8.decode(response.bodyBytes));
        return Quote.fromJson(data);
      } else {
        throw Exception('เซิร์ฟเวอร์ตอบผิดพลาด (${response.statusCode})');
      }
    } on SocketException {
      throw Exception('เชื่อมต่อไม่ได้ กรุณาตรวจสอบอินเทอร์เน็ต');
    } on TimeoutException {
      throw Exception('การเชื่อมต่อหมดเวลา (Timeout) กรุณาลองใหม่');
    } catch (e) {
      throw Exception('เชื่อมต่อไม่ได้ ตรวจสอบอินเทอร์เน็ต');
    }
  }

  // ดึงคำคมสำหรับหน้าเกี่ยวกับ (โบนัส API หน้าที่สอง)
  static Future<String> fetchDailyInspiration() async {
    try {
      final quote = await fetchQuote();
      return '"${quote.quote}"\n— ${quote.author}';
    } catch (_) {
      return '"ทุกวันคือโอกาสในการเริ่มต้นสิ่งใหม่ๆ"';
    }
  }
}

// ==========================================
// 3. Application Root
// ==========================================
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MyDiary',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const MainPage(),
    );
  }
}

// ==========================================
// 4. หน้าหลัก (BottomNavigationBar)
// ==========================================
class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = const [
    DiaryListPage(),
    AboutPage(),
    PokemonPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.book), label: 'บันทึก'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'เกี่ยวกับ'),
          BottomNavigationBarItem(
            icon: Icon(Icons.catching_pokemon),
            label: 'โปเกเดกซ์',
          ),
        ],
      ),
    );
  }
}

class Pokemon {
  final int id;
  final String name;
  final int height;
  final int weight;
  final String imageUrl;
  final List<String> types;

  Pokemon({
    required this.id,
    required this.name,
    required this.height,
    required this.weight,
    required this.imageUrl,
    required this.types,
  });

  factory Pokemon.fromJson(Map<String, dynamic> json) {
    return Pokemon(
      id: json['id'] as int? ?? 0,
      name: json['name'] as String? ?? 'ไม่ทราบชื่อ',
      height: json['height'] as int? ?? 0,
      weight: json['weight'] as int? ?? 0,
      imageUrl: json['sprites']?['front_default'] as String? ?? '',
      types: (json['types'] as List<dynamic>? ?? [])
          .map((t) => t['type']['name'] as String)
          .toList(),
    );
  }
}

class PokeApiService {
  PokeApiService._();

  static Future<Pokemon> fetchRandomPokemon() async {
    try {
      final randomId = DateTime.now().microsecondsSinceEpoch % 898 + 1;
      final url = Uri.parse('https://pokeapi.co/api/v2/pokemon/$randomId');
      final response = await http.get(url).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(utf8.decode(response.bodyBytes));
        return Pokemon.fromJson(data);
      } else {
        throw Exception('เซิร์ฟเวอร์ตอบผิดพลาด (${response.statusCode})');
      }
    } on SocketException {
      throw Exception('เชื่อมต่อไม่ได้ กรุณาตรวจสอบอินเทอร์เน็ต');
    } on TimeoutException {
      throw Exception('การเชื่อมต่อหมดเวลา (Timeout) กรุณาลองใหม่');
    } catch (e) {
      throw Exception('เชื่อมต่อไม่ได้ ตรวจสอบอินเทอร์เน็ต');
    }
  }
}

class PokemonPage extends StatefulWidget {
  const PokemonPage({super.key});
  @override
  State<PokemonPage> createState() => _PokemonPageState();
}

class _PokemonPageState extends State<PokemonPage> {
  late Future<Pokemon> _pokemonFuture;

  @override
  void initState() {
    super.initState();
    _fetchNewPokemon();
  }

  void _fetchNewPokemon() {
    setState(() {
      _pokemonFuture = PokeApiService.fetchRandomPokemon();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('สุ่มโปเกม่อน')),
      body: Center(
        child: FutureBuilder<Pokemon>(
          future: _pokemonFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
            return const Padding(
              padding: EdgeInsets.symmetric(vertical: 24, horizontal: 16),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 10),
                    Text(
                      'กำลังโหลดโปเกม่อน...',
                      style: TextStyle(color: Colors.grey, fontSize: 14),
                    ),
                  ],
                ),
              ),
            );
          }
            if (snapshot.hasError) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('เกิดข้อผิดพลาด: ${snapshot.error}'),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _fetchNewPokemon,
                    child: const Text('ลองใหม่'),
                  ),
                ],
              );
            }
            final p = snapshot.data!;
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (p.imageUrl.isNotEmpty)
                Text('โหลดโปเกม่อนสำเร็จ'),
                  Image.network(p.imageUrl, height: 180),
                Text(
                  p.name.toUpperCase(),
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                Text('ส่วนสูง: ${p.height} | น้ำหนัก: ${p.weight}'),
                Text('ประเภท: ${p.types.join(', ')}'),
                const SizedBox(height: 12),
                ElevatedButton(
                  onPressed: _fetchNewPokemon,
                  child: const Text('สุ่มใหม่'),
                ),
                ElevatedButton(
                  onPressed: _fetchNewPokemon,
                  child: const Text('บันทึกโปเกม่อน'),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

// ==========================================
// 5. หน้ารายการบันทึก (มี FutureBuilder การ์ดคำคม + SQLite)
// ==========================================
class DiaryListPage extends StatefulWidget {
  const DiaryListPage({super.key});

  @override
  State<DiaryListPage> createState() => _DiaryListPageState();
}

class _DiaryListPageState extends State<DiaryListPage> {
  List<Diary> diaries = [];
  late Future<Quote> _quoteFuture;

  final List<Color> colors = [
    Colors.indigo,
    Colors.teal,
    Colors.orange,
    Colors.pink,
    Colors.green,
  ];

  @override
  void initState() {
    super.initState();
    _loadDiaries();
    _fetchNewQuote();
  }

  void _fetchNewQuote() {
    setState(() {
      _quoteFuture = ApiService.fetchQuote();
    });
  }

  Future<void> _loadDiaries() async {
    final data = await DatabaseHelper.getAll();
    setState(() {
      diaries = data;
    });
  }

  Future<void> _addDiary(Diary diary) async {
    await DatabaseHelper.insert(diary);
    await _loadDiaries();
  }

  Future<void> _updateDiary(Diary diary) async {
    await DatabaseHelper.update(diary);
    await _loadDiaries();
  }

  Future<void> _deleteDiary(int id) async {
    await DatabaseHelper.delete(id);
    await _loadDiaries();
  }

  Future<void> _confirmDelete(int index) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ลบบันทึก?'),
        content: Text('ต้องการลบ "${diaries[index].title}" ใช่ไหม'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('ยกเลิก'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('ลบ', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (confirm == true) {
      _deleteDiary(diaries[index].id!);
    }
  }

  // Lab 3: บันทึกคำคมที่ดึงมาจาก API ลงใน SQLite
  Future<void> _saveQuoteToDiary(Quote quote) async {
    final today = DateTime.now().toString().substring(0, 10);
    final diaryFromQuote = Diary(
      title: 'คำคมโดนใจ: ${quote.author}',
      content: '"${quote.quote}"\n\n(บันทึกอัตโนมัติจากคำคมออนไลน์)',
      date: today,
      mood: 'ตื่นเต้น',
    );

    await _addDiary(diaryFromQuote);

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('บันทึกคำคมของ "${quote.author}" ลงไดอารีเรียบร้อยแล้ว!'),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // Widget การ์ดแสดงคำคมจากเน็ต (Lab 1)
  Widget _buildQuoteCard() {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: FutureBuilder<Quote>(
        future: _quoteFuture,
        builder: (context, snapshot) {
          // Lab 1 (ขั้นที่ 2): แสดงสถานะโหลดพร้อมข้อความ
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Padding(
              padding: EdgeInsets.symmetric(vertical: 24, horizontal: 16),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 10),
                    Text(
                      'กำลังโหลดคำคม...',
                      style: TextStyle(color: Colors.grey, fontSize: 14),
                    ),
                  ],
                ),
              ),
            );
          }

          // Lab 1 (ขั้นที่ 1) & Lab 2: แสดงสถานะ Error พร้อมปุ่มลองใหม่
          if (snapshot.hasError) {
            return Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.wifi_off, color: Colors.redAccent, size: 36),
                  const SizedBox(height: 6),
                  Text(
                    snapshot.error.toString().replaceAll('Exception: ', ''),
                    style: const TextStyle(color: Colors.grey, fontSize: 13),
                    textAlign: TextAlign.center,
                  ),
                  TextButton.icon(
                    onPressed: _fetchNewQuote,
                    icon: const Icon(Icons.refresh, size: 18),
                    label: const Text('ลองใหม่'),
                  ),
                ],
              ),
            );
          }

          // เมื่อโหลดข้อมูลสำเร็จ (ก4)
          final quote = snapshot.data!;
          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.format_quote,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        const SizedBox(width: 6),
                        const Text(
                          'คำคมประจำวัน (API)',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                    IconButton(
                      icon: const Icon(Icons.refresh, size: 20),
                      tooltip: 'รีเฟรชคำคมใหม่',
                      onPressed: _fetchNewQuote,
                    ),
                  ],
                ),
                Text(
                  '"${quote.quote}"',
                  style: const TextStyle(
                    fontStyle: FontStyle.italic,
                    fontSize: 15,
                    height: 1.3,
                  ),
                ),
                const SizedBox(height: 6),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    '— ${quote.author}',
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Colors.black54,
                    ),
                  ),
                ),
                const Divider(height: 20),
                // Lab 3: ปุ่มบันทึกคำคมลง SQLite
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () => _saveQuoteToDiary(quote),
                    icon: const Icon(Icons.bookmark_add_outlined, size: 18),
                    label: const Text('บันทึกคำคมที่ชอบลงสมุดบันทึก'),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('บันทึกของฉัน (${diaries.length})'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // ส่วนที่ 1: การ์ดคำคมจากเน็ต (Lab 1, 2, 3)
          _buildQuoteCard(),

          // ส่วนที่ 2: รายการบันทึกจาก SQLite
          Expanded(
            child: diaries.isEmpty
                ? const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.book_outlined, size: 80, color: Colors.grey),
                        SizedBox(height: 16),
                        Text(
                          'ยังไม่มีบันทึก',
                          style: TextStyle(fontSize: 18, color: Colors.grey),
                        ),
                        Text(
                          'กดปุ่ม + หรือบันทึกจากคำคมด้านบน',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: diaries.length,
                    itemBuilder: (context, i) {
                      return Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        child: ListTile(
                          leading: Icon(
                            Icons.book,
                            color: colors[i % colors.length],
                          ),
                          title: Text(diaries[i].title),
                          subtitle: Text(
                            '${diaries[i].mood} • ${diaries[i].date}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(
                                  Icons.edit,
                                  color: Colors.blue,
                                ),
                                onPressed: () async {
                                  final result = await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          AddDiaryPage(existing: diaries[i]),
                                    ),
                                  );
                                  if (result != null && result is Diary) {
                                    await _updateDiary(result);
                                  }
                                },
                              ),
                              IconButton(
                                icon: const Icon(
                                  Icons.delete,
                                  color: Colors.red,
                                ),
                                onPressed: () => _confirmDelete(i),
                              ),
                            ],
                          ),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    DiaryDetailPage(diary: diaries[i]),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AddDiaryPage()),
          );

          if (result != null && result is Diary) {
            await _addDiary(result);
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}

// ==========================================
// 6. หน้าเพิ่ม / แก้ไขบันทึก (เดิม)
// ==========================================
class AddDiaryPage extends StatefulWidget {
  final Diary? existing;

  const AddDiaryPage({super.key, this.existing});

  @override
  State<AddDiaryPage> createState() => _AddDiaryPageState();
}

class _AddDiaryPageState extends State<AddDiaryPage> {
  final _formKey = GlobalKey<FormState>();

  final _titleController = TextEditingController();
  final _contentController = TextEditingController();

  String _selectedMood = 'มีความสุข';

  final List<String> _moods = [
    'มีความสุข',
    'เฉยๆ',
    'เศร้า',
    'เหนื่อย',
    'ตื่นเต้น',
  ];

  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    final existing = widget.existing;
    if (existing != null) {
      _titleController.text = existing.title;
      _contentController.text = existing.content;
      _selectedMood = existing.mood;
      _selectedDate = DateTime.tryParse(existing.date) ?? DateTime.now();
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.existing != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'แก้ไขบันทึก' : 'เขียนบันทึกใหม่'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'ชื่อเรื่อง',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'กรุณากรอกชื่อเรื่อง';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _contentController,
                maxLines: 5,
                decoration: const InputDecoration(
                  labelText: 'เนื้อหา',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'กรุณากรอกเนื้อหา';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _selectedMood,
                decoration: const InputDecoration(
                  labelText: 'อารมณ์วันนี้',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.mood),
                ),
                items: _moods.map((mood) {
                  return DropdownMenuItem(value: mood, child: Text(mood));
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedMood = value!;
                  });
                },
              ),
              const SizedBox(height: 16),
              ListTile(
                leading: const Icon(Icons.calendar_today),
                title: Text(
                  'วันที่: ${_selectedDate.toString().substring(0, 10)}',
                ),
                trailing: const Icon(Icons.edit),
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: _selectedDate,
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2030),
                  );

                  if (picked != null) {
                    setState(() {
                      _selectedDate = picked;
                    });
                  }
                },
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: FilledButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      final newDiary = Diary(
                        id: widget.existing?.id,
                        title: _titleController.text.trim(),
                        content: _contentController.text.trim(),
                        date: _selectedDate.toString().substring(0, 10),
                        mood: _selectedMood,
                      );

                      Navigator.pop(context, newDiary);
                    }
                  },
                  child: Text(isEditing ? 'บันทึกการแก้ไข' : 'บันทึก'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// 7. หน้ารายละเอียดบันทึก (เดิม)
// ==========================================
class DiaryDetailPage extends StatelessWidget {
  final Diary diary;

  const DiaryDetailPage({super.key, required this.diary});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('รายละเอียด')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              diary.title,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              diary.date,
              style: const TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 8),
            Text('อารมณ์: ${diary.mood}', style: const TextStyle(fontSize: 16)),
            const Divider(height: 32),
            Text(
              diary.content,
              style: const TextStyle(fontSize: 16, height: 1.6),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 8. หน้าเกี่ยวกับ (โบนัส +1: แสดงข้อมูลเน็ตหลายหน้า)
// ==========================================
class AboutPage extends StatefulWidget {
  const AboutPage({super.key});

  @override
  State<AboutPage> createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  late Future<String> _quoteFuture;

  @override
  void initState() {
    super.initState();
    _quoteFuture = ApiService.fetchDailyInspiration();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('เกี่ยวกับ')),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.indigo,
                  child: Icon(Icons.book, size: 50, color: Colors.white),
                ),
                const SizedBox(height: 20),
                const Text(
                  'MyDiary',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                const Text('แอปสมุดบันทึกส่วนตัว'),
                const SizedBox(height: 4),
                const Text('สร้างโดย นางสาวช่อทิพย์ ลือจันดา'),
                const Text('รหัสนักศึกษา 67011212113'),
                const SizedBox(height: 8),
                const Text(
                  'เวอร์ชัน 3.0 (SQLite + Online API)',
                  style: TextStyle(color: Colors.grey),
                ),
                const SizedBox(height: 24),

                // ข้อความสร้างแรงบันดาลใจจากเน็ต (API ตัวที่สอง)
                FutureBuilder<String>(
                  future: _quoteFuture,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const LinearProgressIndicator();
                    }
                    return Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.indigo.shade50,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.indigo.shade200),
                      ),
                      child: Column(
                        children: [
                          const Icon(Icons.format_quote, color: Colors.indigo),
                          const SizedBox(height: 6),
                          Text(
                            snapshot.data ?? '',
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontStyle: FontStyle.italic),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class AddPokemonPage extends StatefulWidget {
  const AddPokemonPage({super.key});
  @override
  State<AddPokemonPage> createState() => _AddPokemonPageState();
}

class _AddPokemonPageState extends State<AddPokemonPage> {
  final _formKey = GlobalKey<FormState>();          // กุญแจคุมฟอร์ม
  final _titleController = TextEditingController();  // อ่านค่าช่องชื่อเรื่อง
  final _contentController = TextEditingController();// อ่านค่าช่องเนื้อหา

  @override
  void dispose() {
    _titleController.dispose();       // คืนทรัพยากรตอนปิดหน้า
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('บันทึกโปเกม่อนใหม่')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'ชื่อเรื่อง',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'กรุณากรอกชื่อเรื่อง';
                  }
                  return null;        // null = ผ่าน
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _contentController,
                maxLines: 5,          // ช่องเนื้อหาสูง 5 บรรทัด
                decoration: const InputDecoration(
                  labelText: 'เนื้อหา',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'กรุณากรอกเนื้อหา';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    // ขั้นถัดไปจะเติมโค้ดบันทึกตรงนี้
                  },
                  child: const Text('บันทึก'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}